/* OOQP                                                               *
 * Authors: E. Michael Gertz, Stephen J. Wright                       *
 * (C) 2001 University of Chicago. See Copyright Notification in OOQP */

/* PARDISO Solver Implemented by J.Currie September 2011 */

#ifndef PARDISOQPGENFACTORY
#define PARDISOQPGENFACTORY

#include "QpGenSparseSeq.h"

class QpGenSparsePardiso : public QpGenSparseSeq {
public:
  QpGenSparsePardiso( int nx, int my, int mz,
		       int nnzQ, int nnzA, int nnzC );
  LinearSystem * makeLinsys( Data * prob_in );
};

#endif
